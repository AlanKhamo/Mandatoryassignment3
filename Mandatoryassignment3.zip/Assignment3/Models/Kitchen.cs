﻿namespace Assignment3.Models
{
	public class Kitchen
	{
		public int Id { get; set; }
		public int ExpectedAdults { get; set; }
		public int ExpectedChildren { get; set; }
		public int CheckedInAdultes { get; set; }
		public int CheckecInChilds { get; set; }
		public int MissingAdults { get; set; }
		public int MissingChildren { get; set; }
	}
}

﻿namespace Assignment3.Hub
{
    public interface IKitchenHub
    {
        Task KitchenUpdate();
    }

}
